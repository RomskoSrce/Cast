@extends('admin.layouts.app')

@section('panel')
    <div class="row mb-none-30 justify-content-center">
        <div class="col-lg-7 col-md-3 mb-30">
            <div class="card b-radius--5">
                <div class="card-body p-0">
                    
                </div>
            </div>
        </div>
    </div>
@endsection
