<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH C:\xampp7.4\htdocs\radioallomas\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>